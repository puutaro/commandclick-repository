
jsimport "${selectTyperGetRecentUrlFromHisConJsPath}";
jsimport "${selectTyperSaveRecentUrlToHistoryPath}";

saveRecentUrlToHistory();

