

jsimport `${selectTyperDeactivateInputTextPath}`;
jsimport `${selectTyperSendTabKeyActionJsPath}`;

sendTabKeyAction(
	"tab",
	"shift___tab",
);
