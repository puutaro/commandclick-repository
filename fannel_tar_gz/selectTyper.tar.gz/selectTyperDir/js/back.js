

jsimport `${selectTyperDeactivateInputTextPath}`;
jsimport `${selectTyperSendTabKeyActionJsPath}`;


sendTabKeyAction(
	"shift___tab",
	"tab",
);