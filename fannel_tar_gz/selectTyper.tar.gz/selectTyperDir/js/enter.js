

jsSendKey.send("enter");