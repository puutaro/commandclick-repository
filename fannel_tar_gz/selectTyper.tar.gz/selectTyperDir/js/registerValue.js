
jsimport `${selectTyperUpdateSeachWordListJsPath}`;

updateSeachWordList(
	`${valueList}`,
	"${selectTyperSelectScriptDirPath}",
	"${selectTyperSelectValueListTxtPath}",
);


