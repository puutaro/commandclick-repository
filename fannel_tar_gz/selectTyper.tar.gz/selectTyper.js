

/// LABELING_SECTION_START
// https://github.com/puutaro/selectTyper
/// LABELING_SECTION_END


/// SETTING_SECTION_START
editExecute="ALWAYS"
onAutoExec="ON"
disableSettingValsEdit="ON"
onTermBackendWhenStart="OFF"
onTermVisibleWhenKeyboard="ON"
onTermShortWhenLoad="ON"
onUpdateLastModify="ON"
onUrlHistoryRegister="ON"
playButtonConfig="icon=black_history,caption=urlHistory,click=func=URL_HISTORY,longClick=func="
settingButtonConfig="icon=open_close,caption=opnClse,click=func=SIZING,longClick=func="
terminalFontZoom="0"
setReplaceVariables="file://"
setVariableTypes="file://"
hideSettingVariables="file://"
scriptFileName="selectTyper.js"
/// SETTING_SECTION_END


/// CMD_VARIABLE_SECTION_START
firstButtons=""
secondButtons=""
valueList=""
/// CMD_VARIABLE_SECTION_END


/// Please write bellow with javascript


