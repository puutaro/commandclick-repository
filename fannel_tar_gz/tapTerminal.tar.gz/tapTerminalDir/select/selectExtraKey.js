

const selectExtraKey = "${SELECT_ITEM}";
if(!selectExtraKey) exitZero();
jsSendKey.send(selectExtraKey);
