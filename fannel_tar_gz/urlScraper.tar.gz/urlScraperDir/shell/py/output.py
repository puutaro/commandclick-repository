from libs.summarize import Summarize

summarize = Summarize()
summarize.exec()

