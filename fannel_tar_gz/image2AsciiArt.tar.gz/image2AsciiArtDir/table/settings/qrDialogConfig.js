
mode=tsvEdit,

logo=
    oneSideLength=60
    |icon=
        nameConfigPath=`${image2AsciiArtTableIconNameColorConfigPath}`,