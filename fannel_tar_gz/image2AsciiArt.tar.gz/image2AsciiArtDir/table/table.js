

/// SETTING_SECTION_START
settingImport=`${FANNEL_PATH}`
importDisableValList=`file://${image2AsciiArtTableImportDisableValListPath}`
terminalDo="OFF"
setVariableTypes=`file://${setVariableTypesForTable}`
qrDialogConfig=`file://${image2AsciiArtTableQrDialogConfigPath}`
listIndexConfig=`file://${image2AsciiArtTableListIndexConfigPath}`
settingButtonConfig=`file://${image2AsciiArtTableSettingBtnConfigPath}`
hideSettingVariables="ascii"
hideSettingVariables=`file://${configHidValPath}`
/// SETTING_SECTION_END

