
name="shortcut"
|icon=shortcut
|func=SHORTCUT,

