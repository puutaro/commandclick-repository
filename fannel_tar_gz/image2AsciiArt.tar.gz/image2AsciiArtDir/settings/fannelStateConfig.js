

// firstState="ascii",

noRegisterStates="config",