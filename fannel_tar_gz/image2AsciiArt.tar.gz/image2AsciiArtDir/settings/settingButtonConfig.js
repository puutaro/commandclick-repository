
disable=ON,

color=gray,

icon=setting,

click=
    func=D_MENU
        ?args=
            menuPath=
                `${image2AsciiArtSettingClickMenuConfigPath}`
                &title="Util",


longClick=
    func=D_MENU
        ?args=
            menuPath=
                `${image2AsciiArtSettingLongClickMenuConfigPath}`
            &title="Emergency menu",

