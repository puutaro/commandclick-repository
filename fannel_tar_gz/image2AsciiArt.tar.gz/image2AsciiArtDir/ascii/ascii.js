

/// SETTING_SECTION_START
settingImport=`${FANNEL_PATH}`
importDisableValList="hideSettingVariables"
terminalDo="OFF"
setVariableTypes=`file://${setVariableTypesForAscii}`
hideSettingVariables="table"
hideSettingVariables=`file://${configHidValPath}`
qrDialogConfig=`file://${image2AsciiArtAsciiQrDialogConfigPath}`
playButtonConfig=`file://${image2AsciiArtAsciiPlayButtonConfigPath}`
editButtonConfig=`file://${image2AsciiArtAsciiEditButtonConfigPath}`
settingButtonConfig=`file://${image2AsciiArtAsciiSettingButtonConfigPath}`
listIndexConfig=`file://${image2AsciiArtAsciiListIndexConfigPath}`
/// SETTING_SECTION_END
