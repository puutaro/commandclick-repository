
visible=ON,

disable=OFF,
    color=darkGreen,

click=
    acVar=runToTableState
        ?importPath=`${image2AsciiArtChangeStateAction}`
        ?replace=
            STATE=`${TABLE}`,
