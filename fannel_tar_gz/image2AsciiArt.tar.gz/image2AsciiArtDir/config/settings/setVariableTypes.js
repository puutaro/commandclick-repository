
playMode:
	LBL:CB=
		${TXT_LABEL}=this
		|
			ordinaly?shuffle?reverse,
pitch:
	TXT:NUM=
		?1..100?1,

toLang:
	CB=
		-?ja?en?zh?es?ko,
