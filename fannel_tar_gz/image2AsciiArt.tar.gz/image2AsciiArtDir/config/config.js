

/// SETTING_SECTION_START
settingImport=`${FANNEL_PATH}`
importDisableValList="hideSettingVariables"
terminalDo="OFF"
hideSettingVariables="appHeader,table,ascii,playBtns"
hideSettingVariables="extraButton,description"
qrDialogConfig="mode=tsvEdit,logo=oneSideLength=40"
setVariableTypes=`file://${setVariableTypesForConfig}`
playButtonConfig=`file://${image2AsciiArtPlayButtonConfigPath}`
editButtonConfig="visible=OFF"
settingButtonConfig="visible=OFF"
/// SETTING_SECTION_END
