// js/action

acVar=runGetAscii
    ?importPath=
        `${image2AsciiArtGetSpannableAction}`
    ?replace=
        ASCII_STATE_LIST_DIR_PATH=`${image2AsciiArtGalleryAsciiDirPath}`,

