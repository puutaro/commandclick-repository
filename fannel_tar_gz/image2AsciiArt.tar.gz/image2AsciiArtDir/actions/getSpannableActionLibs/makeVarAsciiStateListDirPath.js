
|var=varAsciiStateListDirPath
    ?value=`{{ ASCII_STATE_LIST_DIR_PATH }}`
    ?varReturn='${it}'