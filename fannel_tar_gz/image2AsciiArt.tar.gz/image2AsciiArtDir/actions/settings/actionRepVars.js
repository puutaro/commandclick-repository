
// js action
image2AsciiArtChangeStateAction=
    `${image2AsciiArtActionsDirPath}/changeStateAction.js`,
image2AsciiArtAction=
    `${image2AsciiArtActionsDirPath}/image2AsciiArtAction.js`,
image2AsciiArtCopyToOtherAction=
    `${image2AsciiArtActionsDirPath}/copyToOther.js`,
image2AsciiArtSpannableWebViewAction=
    `${image2AsciiArtActionsDirPath}/spannableWebViewAction.js`,
image2AsciiArtGetSpannableAction=
    `${image2AsciiArtActionsDirPath}/getSpannableAction.js`,
image2AsciiArtDeleteWithAction=
    `${image2AsciiArtActionsDirPath}/deleteWithAction.js`,
image2AsciiArtLongPressAction=
    `${image2AsciiArtActionsDirPath}/longPressAction.js`,


image2AsciiArtCopyToOtherAcLibs=
    `${image2AsciiArtActionsDirPath}/copyToOtherLibs`,
image2AsciiArtGetSpannableActionLibs=
    `${image2AsciiArtActionsDirPath}/getSpannableActionLibs`,
