

/// SETTING_SECTION_START
settingImport=`${FANNEL_PATH}`
importDisableValList="hideSettingVariables"
terminalDo="OFF"
setVariableTypes=`file://${setVariableTypesForImage}`
hideSettingVariables="table"
hideSettingVariables=`file://${configHidValPath}`
qrDialogConfig=`file://${image2AsciiArtImageQrDialogConfigPath}`
playButtonConfig=`file://${image2AsciiArtImagePlayButtonConfigPath}`
editButtonConfig=`file://${image2AsciiArtImageEditButtonConfigPath}`
settingButtonConfig=`file://${image2AsciiArtImageSettingButtonConfigPath}`
listIndexConfig=`file://${image2AsciiArtImageListIndexConfigPath}`
/// SETTING_SECTION_END
