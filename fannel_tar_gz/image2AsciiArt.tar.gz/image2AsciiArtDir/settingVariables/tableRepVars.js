

// css
iconColor=ligthBlue,
iconBkColor=white,

// dir path
image2AsciiArtTableDirPath=
    `${image2AsciiArtDirPath}/table`,
image2AsciiArtTableSettingsDirPath=
    `${image2AsciiArtTableDirPath}/settings`,

// setting file path
image2AsciiArtTableTsvPath=
    `${image2AsciiArtTableSettingsDirPath}/table.tsv`,
image2AsciiArtTableFannelPath=
    `${image2AsciiArtTableDirPath}/table.js`,
setVariableTypesForTable=
    `${image2AsciiArtTableSettingsDirPath}/setVariableTypes.js`,
image2AsciiArtTableQrDialogConfigPath=
    `${image2AsciiArtTableSettingsDirPath}/qrDialogConfig.js`,
image2AsciiArtTableListIndexConfigPath=
    `${image2AsciiArtTableSettingsDirPath}/listIndexConfig.js`,
image2AsciiArtTableSettingBtnConfigPath=
    `${image2AsciiArtTableSettingsDirPath}/settingButtonConfig.js`,
image2AsciiArtTableInitTsvConPath=
    `${image2AsciiArtTableSettingsDirPath}/initList.tsv`,
image2AsciiArtTableLongPressListIndexMenuPath=
    `${image2AsciiArtTableSettingsDirPath}/longClickListIndexMenu.js`,
image2AsciiArtTableIconNameColorConfigPath=
    `${image2AsciiArtTableSettingsDirPath}/iconNameColorConfig.tsv`,
image2AsciiArtTableImportDisableValListPath=
    `${image2AsciiArtTableSettingsDirPath}/importDisableValList.js`,