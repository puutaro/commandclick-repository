

// dir path
image2AsciiArtAsciiDirPath=
    `${image2AsciiArtDirPath}/ascii`,
image2AsciiArtAsciiSettingsDirPath=
    `${image2AsciiArtAsciiDirPath}/settings`,
image2AsciiArtAsciiActionsDirPath=
    `${image2AsciiArtAsciiDirPath}/actions`,

// setting file path
image2AsciiArtAsciiFannelPath=
    `${image2AsciiArtAsciiDirPath}/ascii.js`,
setVariableTypesForAscii=
    `${image2AsciiArtAsciiSettingsDirPath}/setVariableTypes.js`,
image2AsciiArtAsciiListIndexConfigPath=
    `${image2AsciiArtAsciiSettingsDirPath}/listIndexConfig.js`,
image2AsciiArtAsciiPlayButtonConfigPath=
    `${image2AsciiArtAsciiSettingsDirPath}/playButtonConfig.js`,
image2AsciiArtAsciiEditButtonConfigPath=
    `${image2AsciiArtAsciiSettingsDirPath}/editButtonConfig.js`,
image2AsciiArtAsciiSettingButtonConfigPath=
    `${image2AsciiArtAsciiSettingsDirPath}/settingButtonConfig.js`,
image2AsciiArtAsciiQrDialogConfigPath=
    `${image2AsciiArtAsciiSettingsDirPath}/qrDialogConfig.js`,

// tsv
image2AsciiArtAsciiListIndexTsvPath=
    `${image2AsciiArtAsciiSettingsDirPath}/listIndex.tsv`,

// action Path
image2AsciiArtQuizAction=
        `${image2AsciiArtAsciiActionsDirPath}/quizAction.js`,