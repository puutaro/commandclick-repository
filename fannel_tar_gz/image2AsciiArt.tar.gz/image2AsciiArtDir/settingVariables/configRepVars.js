
image2AsciiArtConfigDirPath=
    `${image2AaciiArtDirPath}/config`,
image2AsciiArtConfigSettingsDirPath=
    `${image2AsciiArtConfigDirPath}/settings`,

// setting file path
image2AsciiArtConfigFannelPath=
    `${image2AsciiArtConfigDirPath}/config.js`,
image2AsciiArtPlayButtonConfigPath=
    `${image2AsciiArtConfigSettingsDirPath}/playButtonConfig.js`,
setVariableTypesForConfig=
    `${image2AsciiArtConfigSettingsDirPath}/setVariableTypes.js`,