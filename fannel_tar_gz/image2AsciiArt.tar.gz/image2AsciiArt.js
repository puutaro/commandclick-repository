

/// LABELING_SECTION_START
// https://github.com/puutaro/image2AsciiArt
/// LABELING_SECTION_END


/// SETTING_SECTION_START
editExecute="ALWAYS"
onUpdateLastModify="ON"
onAdBlock="OFF"
disableSettingValsEdit="ON"
fannelStateConfig=`file://`
playButtonConfig="visible=OFF,disable=ON,color=gray,icon=play"
editButtonConfig="visible=OFF,disable=ON,color=gray,icon=list"
settingButtonConfig=`file://${image2AsciiArtSettingButtonConfigPath}`
setReplaceVariables="file://"
hideSettingVariables="file://"
srcImageAnchorLongPressJsPath=`${image2AsciiArtLongPressAction}`
imageLongPressJsPath=`${image2AsciiArtLongPressAction}`
/// SETTING_SECTION_END


/// CMD_VARIABLE_SECTION_START
appHeader=""
table=""
ascii=""
extraButton=""
/// CMD_VARIABLE_SECTION_END


/// Please write bellow with javascript
