
// setting
TXT_LABEL=
	"label",
LIST_PATH=
	"listPath",
BTN_CMD=
	"cmd",
BTN_LABEL=
	"label",

// dir path
fannelDirPath=
	"${01}/${001}",
savePageUrlDialogListDirPath=
	`${fannelDirPath}/menuList`,
savePageUrlDialogJsDirPath=
	`${fannelDirPath}/js`,


// file path
leftMenuListFilePath=
	`${savePageUrlDialogListDirPath}/leftMenuList.txt`,
leftLongPressMenuListFilePath=
	`${savePageUrlDialogListDirPath}/leftLongPressMenuList.txt`,
centerMenuListFilePath=
	`${savePageUrlDialogListDirPath}/centerMenuList.txt`,
centerLongPressMenuListFilePath=
	`${savePageUrlDialogListDirPath}/centerLongPressMenuList.txt`,
rightMenuListFilePath=
	`${savePageUrlDialogListDirPath}/rightMenuList.txt`,
srcImageAnchorMenuListFilePath=
	`${savePageUrlDialogListDirPath}/srcImageAnchorMenuList.txt`,
srcAnchorMenuListFilePath=
	`${savePageUrlDialogListDirPath}/srcAnchorMenuList.txt`,
imageMenuListFilePath=
	`${savePageUrlDialogListDirPath}/imageMenuList.txt`,

// js path
savePageUrlConJsPath=
	`${savePageUrlDialogJsDirPath}/savePageUrlCon.js`,
longPressUrlRegisterJsPath=
	`${savePageUrlDialogJsDirPath}/longPressUrlRegister.js`,

// tsv path
savePageUrlConArgsTsvPath=
	`${savePageUrlDialogJsDirPath}/argsTsv.tsv`,