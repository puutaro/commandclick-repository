

/// LABELING_SECTION_START
// # displayHtmlSource.js
// ----------------

// Display html source for current page @puutaro
/// LABELING_SECTION_END

/// SETTING_SECTION_START
disableSettingValsEdit="ON"
/// SETTING_SECTION_END

const htmlSource = document.documentElement.outerHTML;
alert(htmlSource);
