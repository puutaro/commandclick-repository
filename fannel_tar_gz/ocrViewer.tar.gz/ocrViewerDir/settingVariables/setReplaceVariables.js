
// basic
TXT_LABEL=label,
BTN_CMD=cmd,
BTN_LABEL=label,
LIST_PATH=listPath,
LIMIT_NUM=limitNum,
FCB_DIR_PATH=dirPath,
FCB_PREFIX=prefix,
FCB_SUFFIX=suffix,
FCB_TYPE=type,
extractMode=extract,
ttsPlayMode=ttsPlay,
clearCache=clearCache,
installMode=install,

// setting
TXT_SUFFIX=".txt",
PDF_SUFFIX=".pdf",


// path
ocrViewerDirPath=
	"${01}/${001}",
ocrViewerListDirPath=
	"${ocrViewerDirPath}/list",
ocrViewerOldPlayDirPath=
	"${ocrViewerDirPath}/old",
ocrViewerTxtListFilePath=
	"${ocrViewerListDirPath}/extractedTxt.txt",
