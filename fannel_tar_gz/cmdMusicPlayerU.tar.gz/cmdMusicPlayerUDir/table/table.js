

/// SETTING_SECTION_START
settingImport=`${FANNEL_PATH}`
importDisableValList="hideSettingVariables"
terminalDo="OFF"
setVariableTypes=`file://${setVariableTypesForTable}`
qrDialogConfig=`file://${cmdMusicPlayerTableQrDialogConfigPath}`
listIndexConfig=`file://${cmdMusicPlayerTableListIndexConfigPath}`
settingButtonConfig=`file://${cmdMusicPlayerTableSettingBtnConfigPath}`
hideSettingVariables="manager,playBtns"
hideSettingVariables=`file://${configHidValPath}`
/// SETTING_SECTION_END

