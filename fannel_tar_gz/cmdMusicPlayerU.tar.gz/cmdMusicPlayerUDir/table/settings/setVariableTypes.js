
appHeader:
    TXTP:RO=
        onUnderLine=OFF
        ?shellPath=MAKE_HEADER_TITLE
        ?args=
            fannelPath=`${FANNEL_PATH}`
            &extraTitle=
        ,

table:
    LI=,

extraButton:
    TXTP:BTN:BTN:HL=
        onUnderLine=OFF
            ?height=`${lineHeight}`
        |${BTN_CMD}= jsac `
                func=ADD
                ?args=
                    compPrefix=${MUSIC_PREFIX}
                    &compSuffix=${TSV_SUFFIX}
                    &dirPath=${cmdMusicPlayerPlayListTableDirPath}
                    &titleArgs=
                        "macro=CAMEL_TO_BLANK_SNAKE
                        ?removeSuffix=PlayList${TSV_SUFFIX}&${TSV_SUFFIX}&List&Play
                        ?compSuffix=List
                        ", 
                `
            ?${BTN_LABEL}="＋"
            ?${BTN_TEXT_SIZE}=`${textSize}`
            ?${BTN_BORDER}=OFF
        |${BTN_CMD}= jsac "func=jsMusic.stop"
            ?${BTN_LABEL}="■"
            ?${BTN_TEXT_SIZE}=`${textSize}`
            ?${BTN_BORDER}=OFF,
