
cmdMusicPlayerConfigDirPath=
    `${cmdMusicPlayerDirPath}/config`,
cmdMusicPlayerConfigSettingsDirPath=
    `${cmdMusicPlayerConfigDirPath}/settings`,

// setting file path
cmdMusicPlayerConfigFannelPath=
    `${cmdMusicPlayerConfigDirPath}/config.js`,
cmdMusicPlayerPlayButtonConfigPath=
    `${cmdMusicPlayerConfigSettingsDirPath}/playButtonConfig.js`,
setVariableTypesForConfig=
    `${cmdMusicPlayerConfigSettingsDirPath}/setVariableTypes.js`,