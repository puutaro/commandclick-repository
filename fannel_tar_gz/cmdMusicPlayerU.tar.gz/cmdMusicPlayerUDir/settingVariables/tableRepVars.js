
// css
iconColor=orange,
iconBkColor=white,

// dir path
cmdMusicPlayerTableDirPath=
    `${cmdMusicPlayerDirPath}/table`,
cmdMusicPlayerTableSettingsDirPath=
    `${cmdMusicPlayerTableDirPath}/settings`,

// setting file path
cmdMusicPlayerTableFannelPath=
    `${cmdMusicPlayerTableDirPath}/table.js`,
setVariableTypesForTable=
    `${cmdMusicPlayerTableSettingsDirPath}/setVariableTypes.js`,
cmdMusicPlayerTableQrDialogConfigPath=
    `${cmdMusicPlayerTableSettingsDirPath}/qrDialogConfig.js`,
cmdMusicPlayerTableIconNameColorConfigPath=
    `${cmdMusicPlayerTableSettingsDirPath}/iconNameColorConfig.tsv`,
cmdMusicPlayerTableListIndexConfigPath=
    `${cmdMusicPlayerTableSettingsDirPath}/listIndexConfig.js`,
cmdMusicPlayerTableTsvPath=
    `${cmdMusicPlayerTableSettingsDirPath}/table.tsv`,
cmdMusicPlayerTableSettingBtnConfigPath=
    `${cmdMusicPlayerTableSettingsDirPath}/settingButtonConfig.js`,
cmdMusicPlayerTableInitTsvConPath=
    `${cmdMusicPlayerTableSettingsDirPath}/initList.tsv`,
cmdMusicPlayerTableLongPressListIndexMenuPath=
    `${cmdMusicPlayerTableSettingsDirPath}/longClickListIndexMenu.js`,
