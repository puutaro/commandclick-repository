

/// SETTING_SECTION_START
settingImport=`${FANNEL_PATH}`
importDisableValList="hideSettingVariables"
terminalDo="OFF"
hideSettingVariables="appHeader,table,manager,playBtns"
hideSettingVariables="extraButton,description"
qrDialogConfig="mode=tsvEdit,logo=oneSideLength=40"
setVariableTypes=`file://${setVariableTypesForConfig}`
playButtonConfig=`file://${cmdMusicPlayerPlayButtonConfigPath}`
editButtonConfig="visible=OFF"
settingButtonConfig="visible=OFF"
/// SETTING_SECTION_END
