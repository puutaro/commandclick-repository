
visible=ON,

disable=OFF,

color=darkGreen,

icon=ok,

click=
    func=jsCmdValSaveAndBack.run_S,
