

/// SETTING_SECTION_START
settingImport=`${FANNEL_PATH}`
importDisableValList="hideSettingVariables"
terminalDo="OFF"
setVariableTypes=`file://${setVariableTypesForManager}`
hideSettingVariables="table,playBtns"
hideSettingVariables=`file://${configHidValPath}`
qrDialogConfig=`file://${cmdMusicPlayerManagerQrDialogConfigPath}`
playButtonConfig=`file://${cmdMusicPlayerManagerPlayButtonConfigPath}`
editButtonConfig=`file://${cmdMusicPlayerManagerEditButtonConfigPath}`
settingButtonConfig=`file://${cmdMusicPlayerManagerSettingButtonConfigPath}`
listIndexConfig=`file://${cmdMusicPlayerManagerListIndexConfigPath}`
/// SETTING_SECTION_END
