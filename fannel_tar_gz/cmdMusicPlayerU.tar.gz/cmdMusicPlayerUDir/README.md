
<div><img src="https://github.com/puutaro/cmdMusicPlayerU/assets/55217593/1e828a08-827e-49ea-b04a-51d83cac752a" width="300">  </div>
  
<div><img src="https://github.com/puutaro/selectTyper/assets/55217593/555e8f5f-656a-4faf-bb76-f663c01cfe47" width="300"></div> 


# cmdMusicPlayerU.js
----------------

Music player @puutaro

Table of Contents
-------
<!-- vim-markdown-toc GFM --> 
* [Installation](#installation)
* [Play list table](#play-list-table)
* [Play list](#play-list)
* [Play](#play)
* [Setting](#setting)
* [About Volume control](#about-volume-control)


## Installation
--------------

1. Install [ComamndClick](https://github.com/puutaro/CommandClick#app-installation) to your android
2. Install this fannel by [install repo](https://github.com/puutaro/CommandClick/blob/master/USAGE.md#install-fannel) or QR code



## Play list table

<a href="https://github.com/puutaro/cmdMusicPlayerU/assets/55217593/17471952-f449-466c-8639-b91b714e7065"><img src="https://github.com/puutaro/cmdMusicPlayerU/assets/55217593/17471952-f449-466c-8639-b91b714e7065" width="300" /></a>

## Play list
<a href="https://github.com/puutaro/cmdMusicPlayerU/assets/55217593/8633303e-32a8-4563-98b0-8075c0891545"><img src="https://github.com/puutaro/cmdMusicPlayerU/assets/55217593/8633303e-32a8-4563-98b0-8075c0891545" width="300" /></a>

## Play

<a href="https://github.com/puutaro/cmdMusicPlayerU/assets/55217593/93d90886-3c09-4709-a0f1-4b4ce1e66211"><img src="https://github.com/puutaro/cmdMusicPlayerU/assets/55217593/93d90886-3c09-4709-a0f1-4b4ce1e66211" width="300" /></a>


## Setting
--------

<a href="https://github.com/puutaro/cmdMusicPlayerU/assets/55217593/ef23153c-5568-4efb-a4d2-23f82c88566e"><img src="https://github.com/puutaro/cmdMusicPlayerU/assets/55217593/ef23153c-5568-4efb-a4d2-23f82c88566e" width="300" /></a>


### About Volume control
Enable when CommandClick hide


