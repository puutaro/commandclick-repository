

name="Kill"
|icon=cancel
|func=KILL,
