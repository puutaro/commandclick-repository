

/// LABELING_SECTION_START
// https://github.com/puutaro/cmdMusicPlayerU
/// LABELING_SECTION_END


/// SETTING_SECTION_START
editExecute="ALWAYS"
onUpdateLastModify="ON"
onAdBlock="OFF"
disableSettingValsEdit="ON"
playButtonConfig="visible=OFF,disable=ON,color=gray,icon=play"
editButtonConfig="visible=OFF,disable=ON,color=gray,icon=list"
settingButtonConfig=`file://${cmdMusicPlayerSettingButtonConfigPath}`
hideSettingVariables="file://"
fannelStateConfig=`file://`
setReplaceVariables="file://"
/// SETTING_SECTION_END


/// CMD_VARIABLE_SECTION_START
appHeader=""
table=""
manager=""
extraButton=""
playBtns=""
playMode="shuffle"
/// CMD_VARIABLE_SECTION_END


/// Please write bellow with javascript
