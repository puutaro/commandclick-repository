
<div><img src="https://github.com/puutaro/selectMenu/assets/55217593/98a49b87-642f-462d-b04c-c0e2addf78c0" width="300">  </div>
  
<div><img src="https://github.com/puutaro/selectTyper/assets/55217593/555e8f5f-656a-4faf-bb76-f663c01cfe47" width="300"></div> 


# selectMenu.js
----------------

Display select menu from jsFile @puutaro

## Installation
--------------

1. Install [ComamndClick](https://github.com/puutaro/CommandClick#app-installation) to your android
2. Install this fannel by [install repo](https://github.com/puutaro/CommandClick/blob/master/USAGE.md#install-fannel) or QR code


## Cmd Variables
--------
### HIGHLIGHT_SCRIPT
Trigger when hilight text is
### EDIT_MENU
Edit fannel menu

| Button type | usage | 
| --------- | --------- |
| DSL button | Drag and sort home fannels list |
| ADD button | Add fannel to home fannel list |

## Setting variables
---------
### EditExecute
Edit mode change

| edit mode | description |
| -------- | -------- |
| `NO` | normal edit |
| `ONCE` | one time edit and execute |
| `ALWAYD` | always edit and execute |
