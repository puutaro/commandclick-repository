// js/action

var=runUbuntuBoot
    ?func=jsUbuntu.boot
|var=runInstallRequirePackage
    ?func=jsUbuntu.execScriptByBackground
    ?args=
        shellPath=`${cmdYoutuberUbuntuInstallShellPath}`
        &argsTabSepaStr=``
        &monitorNum=1
    ,