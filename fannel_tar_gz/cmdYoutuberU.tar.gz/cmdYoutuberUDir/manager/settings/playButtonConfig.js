

visible=ON,
disable=OFF,
color=darkGreen,

click=
    acVar=runNormalPlay
        ?importPath=
            `${cmdYoutuberNormalPlayAction}`,
