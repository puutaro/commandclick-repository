
<div><img src="https://github.com/puutaro/clipFormatMaker/assets/55217593/56ae407d-dddd-4a75-91d8-423e98f94a3a" width="300"></div>
  
<div><img src="https://github.com/puutaro/selectTyper/assets/55217593/555e8f5f-656a-4faf-bb76-f663c01cfe47" width="300"></div> 

# gCalendarFormatter.js
----------------

Set format Google Calendar @puutaro

## Installation
--------------

1. Install [ComamndClick](https://github.com/puutaro/CommandClick#app-installation) to your android
2. Install this fannel by [install repo](https://github.com/puutaro/CommandClick/blob/master/USAGE.md#install-fannel) or QR code


## Toolbar buttons
---------------------

### Play Button
Launch google calendar by cmd variables

## Cmd Variables
--------

### sourceUrl
schedule mail url etc..

### LAUNCH_URL
Launch url
