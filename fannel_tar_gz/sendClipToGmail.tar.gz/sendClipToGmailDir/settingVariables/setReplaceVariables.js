
// basic
TXT_LABEL=label,
BTN_CMD=cmd,
BTN_LABEL=label,
LIST_PATH=listPath,
LIMIT_NUM=limitNum,

// dir path
sendClipToGmailDirPath="${01}/${001}",
sendClipToGmailListDirPath="${sendClipToGmailDirPath}/list",

// file path
sendClipToGmailUrlListFilePath="${sendClipToGmailListDirPath}/gmailUrlList.txt",
sendClipToGmailDraftUrlListFilePath="${sendClipToGmailListDirPath}/gmailDraftUrlList.txt",