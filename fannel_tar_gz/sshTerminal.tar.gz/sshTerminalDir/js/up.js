

jsSendKey.send("${UP}");
