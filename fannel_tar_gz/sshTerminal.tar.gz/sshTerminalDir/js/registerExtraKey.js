
jsimport `${sshTerminalUpdateSearchWordListJsPath}`;

updateSearchWordList(
    `${REGISTER_EXTRA_KEY}`,
    `${sshTerminalListDirPath}`,
    `${sshTerminalExtraKeyListFilePath}`,
);
