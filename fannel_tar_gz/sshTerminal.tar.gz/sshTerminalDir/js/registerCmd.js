
jsimport `${sshTerminalUpdateSearchWordListJsPath}`;

updateSearchWordList(
    `${cmdInput}`,
    `${sshTerminalListDirPath}`,
    `${sshTerminalCmdListFilePath}`,
);
