
jsSendKey.send("${BACKSPACE}");
