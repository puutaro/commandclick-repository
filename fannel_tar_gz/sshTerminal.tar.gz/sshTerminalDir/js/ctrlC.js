
jsSendKey.send("${CTRL_C}");
