

const selectCmd = "${SELECT_ITEM}";
if(!selectCmd) exitZero();
jsSendKey.send(selectCmd);