#!/bin/bash


curl \
	-fsSL \
	https://raw.githubusercontent.com/filebrowser/get/master/get.sh \
	| bash
echo "comp install"
