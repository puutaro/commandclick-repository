

/// LABELING_SECTION_START
// https://github.com/puutaro/fileManager
/// LABELING_SECTION_END


/// SETTING_SECTION_START
editExecute="ALWAYS"
onAutoExec="ON"
onUpdateLastModify="ON"
disableSettingValsEdit="ON"
onAdBlock="OFF"
onUrlHistoryRegister="OFF"
terminalSizeType="LONG"
srcImageAnchorLongPressMenuFilePath=""
srcAnchorLongPressMenuFilePath=""
homeScriptUrlsPath=""
execPlayBtnLongPress="${FILE_MANAGER_SELECT_DIR_DIALOG_JS_PATH}"
execEditBtnLongPress="${FILE_MANAGER_COPY_JS_PATH}"
terminalFontZoom="110"
setReplaceVariables="file://"
setVariableTypes="file://"
hideSettingVariables="file://"
scriptFileName="fileManager.js"
/// SETTING_SECTION_END


/// CMD_VARIABLE_SECTION_START
DIR_PATH_LIST=""
stop=""
SETTING=""
install=""
ROOT_DIR_PATH="/"
BASE_URL=""
IS_LAUNCH_ON_CLICK_URL_HISTORY="OFF"
/// CMD_VARIABLE_SECTION_END


/// Please write bellow with javascript

