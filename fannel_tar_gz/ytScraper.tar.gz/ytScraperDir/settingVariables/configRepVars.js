
cmdYoutuberConfigDirPath=
    `${cmdYoutuberDirPath}/config`,
cmdYoutuberConfigSettingsDirPath=
    `${cmdYoutuberConfigDirPath}/settings`,

// setting file path
cmdYoutuberConfigFannelPath=
    `${cmdYoutuberConfigDirPath}/config.js`,
cmdYoutuberPlayButtonConfigPath=
    `${cmdYoutuberConfigSettingsDirPath}/playButtonConfig.js`,
setVariableTypesForConfig=
    `${cmdYoutuberConfigSettingsDirPath}/setVariableTypes.js`,