
// dir path
cmdYoutuberSearcherDirPath=
    `${cmdYoutuberDirPath}/searcher`,
cmdYoutuberSearcherSettingsDirPath=
    `${cmdYoutuberSearcherDirPath}/settings`,
cmdYoutuberSearcherActionsDirPath=
    `${cmdYoutuberSearcherDirPath}/actions`,
cmdYoutuberSearcherListDirPath=
    `${cmdYoutuberSearcherDirPath}/list`,

// setting file path
cmdYoutuberSearcherFannelPath=
    `${cmdYoutuberSearcherDirPath}/searcher.js`,
setVariableTypesForSearcher=
    `${cmdYoutuberSearcherSettingsDirPath}/setVariableTypes.js`,
cmdYoutuberSearcherListIndexConfigPath=
    `${cmdYoutuberSearcherSettingsDirPath}/listIndexConfig.js`,
cmdYoutuberSearcherPlayButtonConfigPath=
    `${cmdYoutuberSearcherSettingsDirPath}/playButtonConfig.js`,
cmdYoutuberSearcherSettingButtonConfigPath=
    `${cmdYoutuberSearcherSettingsDirPath}/settingButtonConfig.js`,

// search word
cmdYoutuberSearcherPastSearchInfoPath=
    `${cmdYoutuberTempDirPath}/pastSearchInfo.txt`,

// list path
cmdYoutuberSearcherListFilePath=
    `${cmdYoutuberSearcherListDirPath}/searchTextList.txt`,
