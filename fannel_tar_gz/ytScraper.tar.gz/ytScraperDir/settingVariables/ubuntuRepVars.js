
// dir path
cmdYoutuberUbuntuDirPath=
    `${cmdYoutuberDirPath}/ubuntu`,

// shell path
cmdYoutuberUbuntuInstallShellPath=
    `${cmdYoutuberUbuntuDirPath}/install.sh`,
cmdYoutuberUbuntuStopAllProcessShellPath=
    `${cmdYoutuberUbuntuDirPath}/stop_all_process.sh`,
cmdYoutuberUbuntuScrapingShellPath=
    `${cmdYoutuberUbuntuDirPath}/scraping.sh`,
cmdYoutuberUbuntuExecScrapingByCurlShellPath=
	`${cmdYoutuberUbuntuDirPath}/execScrapingByCurl.sh`,
