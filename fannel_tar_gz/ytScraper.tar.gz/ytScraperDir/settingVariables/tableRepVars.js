
// dir path
cmdYoutuberTableDirPath=
    `${cmdYoutuberDirPath}/table`,
cmdYoutuberTableSettingsDirPath=
    `${cmdYoutuberTableDirPath}/settings`,

// css
iconColor=lightGreen,
iconBkColor=white,


// setting file path
cmdYoutuberTableFannelPath=
    `${cmdYoutuberTableDirPath}/table.js`,
cmdYoutuberTableTsvPath=
    `${cmdYoutuberTableSettingsDirPath}/table.tsv`,
setVariableTypesForTable=
    `${cmdYoutuberTableSettingsDirPath}/setVariableTypes.js`,
cmdYoutuberTableListIndexConfigPath=
    `${cmdYoutuberTableSettingsDirPath}/listIndexConfig.js`,
cmdYoutuberTableSettingBtnConfigPath=
    `${cmdYoutuberTableSettingsDirPath}/settingButtonConfig.js`,
cmdYoutuberTableInitTsvConPath=
    `${cmdYoutuberTableSettingsDirPath}/initList.tsv`,
cmdYoutuberTableLongPressListIndexMenuPath=
    `${cmdYoutuberTableSettingsDirPath}/longClickListIndexMenu.js`,
cmdYoutuberTableQrDialogConfigPath=
    `${cmdYoutuberTableSettingsDirPath}/qrDialogConfig.js`,
cmdYoutuberTableIconNameColorConfigPath=
    `${cmdYoutuberTableSettingsDirPath}/iconNameColorConfig.tsv`,