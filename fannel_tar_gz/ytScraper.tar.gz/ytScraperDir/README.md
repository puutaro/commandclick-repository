
<div><img src="https://github.com/puutaro/cmdYoutuberU/assets/55217593/410beeff-7221-456b-aa1e-919daa5f5fdc" width="300">  </div>
  
<div><img src="https://github.com/puutaro/selectTyper/assets/55217593/555e8f5f-656a-4faf-bb76-f663c01cfe47" width="300"></div> 


# ytScraper
---------------------

Youtube scraping background player (**ubuntu version**) @puutaro

Table of Contents
-------
<!-- vim-markdown-toc GFM --> 
* [Installation](#installation)
* [Web search mode](#web-search-mode)
* [Play list table](#play-list-table)
* [Setting](#setting)
* [Support long press menu table](#support-long-press-menu-table)


## Installation
---------------------

1. Install [ComamndClick](https://github.com/puutaro/CommandClick) to your android by [this link](https://github.com/puutaro/CommandClick#app-installation)
2. Set up Ubuntu by [this link](https://github.com/puutaro/CommandClick/blob/master/USAGE.md#setup-ubuntu)
3. Install this fannel by [install repo](https://github.com/puutaro/CommandClick/blob/master/USAGE.md#install-fannel) or QR code
4. Press [Install button](#install)


## Web search mode

<a href="https://github.com/puutaro/CommandClick/assets/55217593/101da895-a578-4667-b8e2-7728bbd9e568"><img src="https://github.com/puutaro/CommandClick/assets/55217593/101da895-a578-4667-b8e2-7728bbd9e568" width="300" /></a>


## Play list table

<a href="https://github.com/puutaro/cmdYoutuberU/assets/55217593/05c7ca2c-836c-45c7-9da9-86732c842190"><img src="https://github.com/puutaro/cmdYoutuberU/assets/55217593/05c7ca2c-836c-45c7-9da9-86732c842190" width="300" /></a>


## Setting
--------

<a href="https://github.com/puutaro/cmdYoutuberU/assets/55217593/cd88506d-f9f3-44b1-987c-0acbb74744fb"><img src="https://github.com/puutaro/cmdYoutuberU/assets/55217593/cd88506d-f9f3-44b1-987c-0acbb74744fb" width="300" /></a>


## Support long press menu table
-------

| type | enable |
| ----- | ----- |
| src anchor | o |
| src image anchor | o |
| image | x |
