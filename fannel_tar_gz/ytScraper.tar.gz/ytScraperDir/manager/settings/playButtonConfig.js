

visible=ON,
disable=OFF,
color=darkGreen,
caption="play",

click=
    acVar=runNormalPlay
        ?importPath=
            `${cmdYoutuberNormalPlayAction}`,
