

/// SETTING_SECTION_START
settingImport=`${FANNEL_PATH}`
importDisableValList="hideSettingVariables"
terminalDo="OFF"
setVariableTypes=`file://${setVariableTypesForManager}`
hideSettingVariables="table,playBtns"
hideSettingVariables=`file://${configHidValPath}`
qrDialogConfig=`file://${cmdYoutuberManagerQrDialogConfigPath}`
    // "mode=tsvEdit,logo=oneSideLength=40"
playButtonConfig=`file://${cmdYoutuberManagerPlayButtonConfigPath}`
editButtonConfig=`file://${cmdYoutuberManagerEditButtonConfigPath}`
settingButtonConfig=`file://${cmdYoutuberManagerSettingButtonConfigPath}`
listIndexConfig=`file://${cmdYoutuberManagerListIndexConfigPath}`
onAutoExec="ON"
autoExecPath=`file://${cmdYoutuberInitActionsPath}`
/// SETTING_SECTION_END
