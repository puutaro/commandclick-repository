
visible=ON,
disable=OFF,
color=darkGreen,
caption="ok",
icon=ok,

click=
    func=jsCmdValSaveAndBack.run_S,
