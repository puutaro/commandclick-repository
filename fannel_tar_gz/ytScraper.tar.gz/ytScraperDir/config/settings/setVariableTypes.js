
playMode:
	LBL:CB=
		${TXT_LABEL}=this
		|
			ordinaly?shuffle?reverse,
