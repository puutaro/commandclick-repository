

/// SETTING_SECTION_START
settingImport=`${FANNEL_PATH}`
importDisableValList="hideSettingVariables"
terminalDo="OFF"
setVariableTypes=`file://${setVariableTypesForTable}`
qrDialogConfig=`file://${cmdYoutuberTableQrDialogConfigPath}`
listIndexConfig=`file://${cmdYoutuberTableListIndexConfigPath}`
settingButtonConfig=`file://${cmdYoutuberTableSettingBtnConfigPath}`
hideSettingVariables="manager,playBtns"
hideSettingVariables=`file://${configHidValPath}`
/// SETTING_SECTION_END

