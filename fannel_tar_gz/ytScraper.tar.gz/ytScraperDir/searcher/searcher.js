
/// SETTING_SECTION_START
settingImport=`${FANNEL_PATH}`
settingImport=`${cmdYoutuberManagerFannelPath}`
importDisableValList="hideSettingVariables"
hideSettingVariables="table,playBtns"
hideSettingVariables=`file://${configHidValPath}`
setVariableTypes=`file://${setVariableTypesForSearcher}`
playButtonConfig=`file://${cmdYoutuberSearcherPlayButtonConfigPath}`
listIndexConfig=`file://${cmdYoutuberSearcherListIndexConfigPath}`
onAutoExec="ON"
autoExecPath=`file://${cmdYoutuberInitActionsPath}`
/// SETTING_SECTION_END
