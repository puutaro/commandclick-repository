
disable=OFF,
color=darkGreen,
icon=setting,

click=
    func=D_MENU
        ?args=
            menuPath=
                ${cmdTtsPlayerManagerSettingMenuPath}
            &title="Setting menu",
