

/// SETTING_SECTION_START
settingImport=`${FANNEL_PATH}`
importDisableValList="hideSettingVariables"
terminalDo="OFF"
setVariableTypes=`file://${setVariableTypesForManager}`
hideSettingVariables="table,playBtns"
hideSettingVariables=`file://${configHidValPath}`
qrDialogConfig=`file://${cmdTtsPlayerManagerQrDialogConfigPath}`
playButtonConfig=`file://${cmdTtsPlayerManagerPlayButtonConfigPath}`
editButtonConfig=`file://${cmdTtsPlayerManagerEditButtonConfigPath}`
settingButtonConfig=`file://${cmdTtsPlayerManagerSettingButtonConfigPath}`
listIndexConfig=`file://${cmdTtsPlayerManagerListIndexConfigPath}`
/// SETTING_SECTION_END
