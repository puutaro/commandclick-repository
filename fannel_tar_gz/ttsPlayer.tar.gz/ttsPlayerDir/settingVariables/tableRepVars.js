

// css
iconColor=ligthBlue,
iconBkColor=white,

// dir path
cmdTtsPlayerTableDirPath=
    `${ttsPlayerDirPath}/table`,
cmdTtsPlayerTableSettingsDirPath=
    `${cmdTtsPlayerTableDirPath}/settings`,

// setting file path
cmdTtsPlayerTableTsvPath=
    `${cmdTtsPlayerTableSettingsDirPath}/table.tsv`,
cmdTtsPlayerTableFannelPath=
    `${cmdTtsPlayerTableDirPath}/table.js`,
setVariableTypesForTable=
    `${cmdTtsPlayerTableSettingsDirPath}/setVariableTypes.js`,
cmdTtsPlayerTableQrDialogConfigPath=
    `${cmdTtsPlayerTableSettingsDirPath}/qrDialogConfig.js`,
cmdTtsPlayerTableListIndexConfigPath=
    `${cmdTtsPlayerTableSettingsDirPath}/listIndexConfig.js`,
cmdTtsPlayerTableSettingBtnConfigPath=
    `${cmdTtsPlayerTableSettingsDirPath}/settingButtonConfig.js`,
cmdTtsPlayerTableSettingMenuConfigPath=
	`${cmdTtsPlayerTableSettingsDirPath}/settingMenuConfig.js`,
cmdTtsPlayerTableInitTsvConPath=
    `${cmdTtsPlayerTableSettingsDirPath}/initList.tsv`,
cmdTtsPlayerTableLongPressListIndexMenuPath=
    `${cmdTtsPlayerTableSettingsDirPath}/longClickListIndexMenu.js`,
cmdTtsPlayerTableIconNameColorConfigPath=
    `${cmdTtsPlayerTableSettingsDirPath}/iconNameColorConfig.tsv`,
cmdTtsPlayerTableImportDisableValListPath=
    `${cmdTtsPlayerTableSettingsDirPath}/importDisableValList.js`,