
cmdTtsPlayerConfigDirPath=
    `${ttsPlayerDirPath}/config`,
cmdTtsPlayerConfigSettingsDirPath=
    `${cmdTtsPlayerConfigDirPath}/settings`,

// setting file path
cmdTtsPlayerConfigFannelPath=
    `${cmdTtsPlayerConfigDirPath}/config.js`,
cmdTtsPlayerPlayButtonConfigPath=
    `${cmdTtsPlayerConfigSettingsDirPath}/playButtonConfig.js`,
setVariableTypesForConfig=
    `${cmdTtsPlayerConfigSettingsDirPath}/setVariableTypes.js`,