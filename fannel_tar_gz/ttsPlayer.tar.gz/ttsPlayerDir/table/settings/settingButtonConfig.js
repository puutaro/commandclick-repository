
color=darkGreen,
disable=OFF,

click=
    func=D_MENU
        ?args=
            menuPath=
                `${cmdTtsPlayerTableSettingMenuConfigPath}`
                &title="Setting menu",
