

/// SETTING_SECTION_START
settingImport=`${FANNEL_PATH}`
importDisableValList=`file://${cmdTtsPlayerTableImportDisableValListPath}`
terminalDo="OFF"
setVariableTypes=`file://${setVariableTypesForTable}`
qrDialogConfig=`file://${cmdTtsPlayerTableQrDialogConfigPath}`
listIndexConfig=`file://${cmdTtsPlayerTableListIndexConfigPath}`
settingButtonConfig=`file://${cmdTtsPlayerTableSettingBtnConfigPath}`
hideSettingVariables="manager,playBtns"
hideSettingVariables=`file://${configHidValPath}`
/// SETTING_SECTION_END

