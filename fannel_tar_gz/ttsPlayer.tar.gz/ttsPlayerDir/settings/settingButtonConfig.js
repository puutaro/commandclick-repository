
disable=ON,

color=gray,

icon=setting,

longClick=
    func=D_MENU
        ?args=
            menuPath=
                `${cmdTtsPlayerSettingLongClickMenuConfigPath}`
            &title="Emergency menu",

