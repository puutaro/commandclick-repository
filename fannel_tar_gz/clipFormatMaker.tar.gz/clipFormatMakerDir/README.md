
<div><img src="https://github.com/puutaro/clipFormatMaker/assets/55217593/782d5635-8eae-4185-8b8c-749352329efa" width="300">  </div>
  
<div><img src="https://github.com/puutaro/selectTyper/assets/55217593/555e8f5f-656a-4faf-bb76-f663c01cfe47" width="300"></div> 


# clipFormatMaker.js
----------------

Create clipboard format by drag & drop @puutaro

## Installation
--------------

1. Install [ComamndClick](https://github.com/puutaro/CommandClick#app-installation) to your android
2. Install this fannel by [install repo](https://github.com/puutaro/CommandClick/blob/master/USAGE.md#install-fannel) or QR code

## Cmd Variable
-------
### creatorJSName
You can decide created jsFileName

1. Input `creatorJSName` or select from grid box 
2. Press play button
