// basic
TXT_LABEL=label,
TXT_LABEL=label,
BTN_CMD=cmd,
BTN_LABEL=label,
LIST_PATH=listPath,
LIMIT_NUM=limitNum,
FCB_DIR_PATH=dirPath,
FCB_PREFIX=prefix,
FCB_SUFFIX=suffix,
FCB_TYPE=type,
ttsPlayMode=ttsPlay,
clearCache=clearCache,
TXT_SUFFIX=".txt",
PDF_SUFFIX=".pdf",

// path
txtPdfViewerDirPath=
	"${01}/${001}",
txtPdfViewerListDirPath=
	"${txtPdfViewerDirPath}/list",
txtPdfViewerStockPlayDirPath=
	"${txtPdfViewerDirPath}/stock",
txtPdfViewerOldPlayDirPath=
	"${txtPdfViewerDirPath}/old",
txtPdfViewerTxtPdfListFilePath=
	"${txtPdfViewerListDirPath}/txtPdf.txt",
