
<div><img src="https://github.com/puutaro/webSearcher/assets/55217593/a09b547c-5cf9-442b-9b38-e0cae87bc44f" width="300">  </div>
  
<div><img src="https://github.com/puutaro/selectTyper/assets/55217593/555e8f5f-656a-4faf-bb76-f663c01cfe47" width="300"></div> 

# webSearcher.js
----------------

Highlight search and web search by dialog @puutaro
## Support long press menu table
---------------

| type | enable |
| ----- | ----- |
| src anchor | o |
| src image anchor | o |
| image | x |

## Installation
--------------

1. Install [ComamndClick](https://github.com/puutaro/CommandClick#app-installation) to your android
2. Install this fannel by [install repo](https://github.com/puutaro/CommandClick/blob/master/USAGE.md#install-fannel) or QR code

