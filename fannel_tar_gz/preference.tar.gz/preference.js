
/// LABELING_SECTION_START
/// LABELING_SECTION_END


/// SETTING_SECTION_START
terminalDo="OFF"
editExecute="ALWAYS"
fannelStateConfig=`file://`
setReplaceVariables="file://"
onUpdateLastModify="OFF"
disableSettingValsEdit="ON"
// webview setting
onAdBlock="ON"
terminalFontZoom=""
terminalFontColor=""
terminalColor=""
terminalOutputMode="NORMAL"
noScrollSaveUrls=""
// long press setting
srcImageAnchorLongPressMenuFilePath=""
srcAnchorLongPressMenuFilePath=""
imageLongPressMenuFilePath=""
// startup setting
onUrlLaunchMacro="RECENT"
onAutoExec="ON"
execJsOrHtmlPath=""
// webview extra setting
defaultMonitorFile="monitor_1"
disableShowToolbarWhenHighlight="OFF"
onTermBackendWhenStart="OFF"
onTermVisibleWhenKeyboard="OFF"
onTermShortWhenLoad="OFF"
// history setting
ignoreHistoryPaths=""
historySwitch="OFF"
urlHistoryOrButtonExec="URL_HISTORY"
onLaunchUrlHistoryByBackstack="ON"
// ubuntu setting
ubuntuSleepDelayMinInScreenOff="20"
onRootfsSdCardSave="OFF"
ubuntuAutoSetup="OFF"
/// SETTING_SECTION_END


/// CMD_VARIABLE_SECTION_START
// webview setting
onAdBlock="ON"
terminalFontZoom=""
terminalFontColor=""
terminalColor=""
terminalOutputMode="NORMAL"
noScrollSaveUrls=""
// long press setting
srcImageAnchorLongPressMenuFilePath=""
srcAnchorLongPressMenuFilePath=""
imageLongPressMenuFilePath=""
// startup setting
onUrlLaunchMacro="RECENT"
onAutoExec="ON"
execJsOrHtmlPath=""
// webview extra setting
defaultMonitorFile="monitor_1"
disableShowToolbarWhenHighlight="OFF"
onTermBackendWhenStart="OFF"
onTermVisibleWhenKeyboard="OFF"
onTermShortWhenLoad="OFF"
// history setting
ignoreHistoryPaths=""
historySwitch="OFF"
urlHistoryOrButtonExec="URL_HISTORY"
onLaunchUrlHistoryByBackstack="ON"
// ubuntu setting
ubuntuSleepDelayMinInScreenOff="20"
onRootfsSdCardSave="OFF"
ubuntuAutoSetup="OFF"
// edit vals
appHeader=""
table=""
/// CMD_VARIABLE_SECTION_END


/// Please write bellow with javascript
