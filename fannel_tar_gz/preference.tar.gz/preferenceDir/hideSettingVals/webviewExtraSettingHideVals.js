// webview setting
onAdBlock,
terminalFontZoom,
terminalFontColor,
terminalColor,
terminalOutputMode,
noScrollSaveUrls,
// long press setting
srcImageAnchorLongPressMenuFilePath,
srcAnchorLongPressMenuFilePath,
imageLongPressMenuFilePath,
// startup setting
onUrlLaunchMacro,
onAutoExec,
execJsOrHtmlPath,
// history setting
ignoreHistoryPaths,
historySwitch,
urlHistoryOrButtonExec,
onLaunchUrlHistoryByBackstack,
// ubuntu setting
ubuntuSleepDelayMinInScreenOff,
onRootfsSdCardSave,
ubuntuAutoSetup,