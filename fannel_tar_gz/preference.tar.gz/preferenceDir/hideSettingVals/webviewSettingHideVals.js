
// long press setting
srcImageAnchorLongPressMenuFilePath,
srcAnchorLongPressMenuFilePath,
imageLongPressMenuFilePath,
// startup setting
onUrlLaunchMacro,
onAutoExec,
execJsOrHtmlPath,
// webview extra setting
defaultMonitorFile,
disableShowToolbarWhenHighlight,
onTermBackendWhenStart,
onTermVisibleWhenKeyboard,
onTermShortWhenLoad,
// history setting
ignoreHistoryPaths,
historySwitch,
urlHistoryOrButtonExec,
onLaunchUrlHistoryByBackstack,
// ubuntu setting
ubuntuSleepDelayMinInScreenOff,
onRootfsSdCardSave,
ubuntuAutoSetup,