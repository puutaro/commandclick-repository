
// init
preferenceTableInitActionsPath=
    `${preferenceActionDirPath}/initAction.js`,
preferenceTableInitAcDirPath=
    `${preferenceActionDirPath}/initAc`,
copyBeforeFileToTempDir=
    `${preferenceTableInitAcDirPath}/copyBeforeFileToTemp.js`,

// change state
preferenceChangeStateActionsPath=
    `${preferenceActionDirPath}/changeStateAction.js`,

// setting button ok action
preferenceSettingEditOkBtnDirPath=
    `${preferenceActionDirPath}/settingEditOk`,
