
// table virtual fannel path
preferenceTableFannelPath=
    `${preferenceTableDirPath}/table.js`,

// setting file path
setVariableTypesForTable=
    `${preferenceTableSettingsDirPath}/setVariableTypes.js`,
tableQrDialogConfigPath=
    `${preferenceTableSettingsDirPath}/qrDialogConfig.js`,
tableListIndexConfigPath=
    `${preferenceTableSettingsDirPath}/listIndexConfig.js`,
preferenceTableTsvPath=
    `${preferenceTableSettingsDirPath}/table.tsv`,
preferenceTableInitTsvPath=
    `${preferenceTableSettingsDirPath}/initList.tsv`,
preferenceTableIconNameColorConfigPath=
    `${preferenceTableSettingsDirPath}/iconNameColorConfig.tsv`,
