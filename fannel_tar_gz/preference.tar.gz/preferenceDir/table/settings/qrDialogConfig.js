
mode=
    tsvEdit,

logo=
    oneSideLength=60
    |icon=
        nameConfigPath=`${preferenceTableIconNameColorConfigPath}`,