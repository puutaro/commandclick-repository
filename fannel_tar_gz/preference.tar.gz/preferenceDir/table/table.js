

/// SETTING_SECTION_START
terminalDo="OFF"
editExecute="ALWAYS"
onUpdateLastModify="OFF"
listIndexConfig=`file://${tableListIndexConfigPath}`
playButtonConfig="visible=OFF,disable=ON,color=gray,icon=play"
editButtonConfig="visible=OFF,disable=ON,color=gray,icon=list"
settingButtonConfig="visible=OFF,disable=ON,color=gray,icon=list"
qrDialogConfig=`file://${tableQrDialogConfigPath}`
hideSettingVariables=`file://${tableHideSettingVariablePath}`
setVariableTypes=`file://${setVariableTypesForTable}`
onAutoExec="ON"
autoExecPath=`file://${preferenceTableInitActionsPath}`
/// SETTING_SECTION_END
