

/// SETTING_SECTION_START
terminalDo="OFF"
editExecute="ALWAYS"
onUpdateLastModify="OFF"
editBoxTitleConfig=`file://${preferenceSettingEditBoxTitleConfigPath}`
playButtonConfig=`file://${preferenceSettingEditPlayButtonConfigPath}`
editButtonConfig=`file://${preferenceSettingEditButtonConfigPath}`
settingButtonConfig="visible=OFF,disable=ON,color=gray,icon=list"
hideSettingVariables="appHeader,table,description"
hideSettingVariables=`file://${dynamicHideSettingVariablePath}`
onAutoExec="ON"
autoExecPath=`file://${preferenceTableInitActionsPath}`
/// SETTING_SECTION_END
