
visible=ON,
icon=list,

click=
    acVar=runToTableState
        ?importPath=`${preferenceChangeStateActionsPath}`
        ?replace=
            STATE=`${TABLE}`,
