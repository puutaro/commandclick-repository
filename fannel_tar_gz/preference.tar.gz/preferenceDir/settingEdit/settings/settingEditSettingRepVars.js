

// state fannel
preferenceSettingEditFannelPath=
    `${preferenceSettingEditDirPath}/settingEdit.js`,

// setting
preferenceSettingEditListIndexTsvPath=
    `${preferenceSettingEditSettingsDirPath}/listIndex.tsv`,
preferenceSettingEditPlayButtonConfigPath=
    `${preferenceSettingEditSettingsDirPath}/playButtonConfig.js`,
preferenceSettingEditButtonConfigPath=
    `${preferenceSettingEditSettingsDirPath}/editButtonConfig.js`,
preferenceSettingEditBoxTitleConfigPath=
    `${preferenceSettingEditSettingsDirPath}/editBoxTitleConfig.js`,