

text=
    shellPath=MAKE_HEADER_TITLE
    |args=
        fannelPath=`${FANNEL_PATH}`
        ?coreTitle=`${coreTitle}`
        ?extraTitle=`file://${preferenceEditInfoPath}`