
// dir path
fannelAppDirPath=
	`${01}`,
fannelDirPath=
	"${01}/${001}",
saveGmailConDialogListDirPath=
	`${fannelDirPath}/menuList`,
saveGmailConDialogJsDirPath=
	`${fannelDirPath}/js`,


// file path
leftMenuListFilePath=
	`${saveGmailConDialogListDirPath}/leftMenuList.txt`,
leftLongPressMenuListFilePath=
	`${saveGmailConDialogListDirPath}/leftLongPressMenuList.txt`,
centerMenuListFilePath=
	`${saveGmailConDialogListDirPath}/centerMenuList.txt`,
centerLongPressMenuListFilePath=
	`${saveGmailConDialogListDirPath}/centerLongPressMenuList.txt`,
rightMenuListFilePath=
	`${saveGmailConDialogListDirPath}/rightMenuList.txt`,
srcImageAnchorMenuListFilePath=
	`${saveGmailConDialogListDirPath}/srcImageAnchorMenuList.txt`,
srcAnchorMenuListFilePath=
	`${saveGmailConDialogListDirPath}/srcAnchorMenuList.txt`,
imageMenuListFilePath=
	`${saveGmailConDialogListDirPath}/imageMenuList.txt`,

// js path
saveGmailConJsPath=
	`${saveGmailConDialogJsDirPath}/saveGmailCon.js`,

// tsv path
saveGmailConArgsTsvPath=
	`${saveGmailConDialogJsDirPath}/argsTsv.tsv`,