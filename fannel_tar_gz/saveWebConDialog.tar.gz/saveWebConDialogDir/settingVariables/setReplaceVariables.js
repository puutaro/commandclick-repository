
// setting
TXT_LABEL=
	"label",
LIST_PATH=
	"listPath",
BTN_CMD=
	"cmd",
BTN_LABEL=
	"label",

// dir path
fannelDirPath=
	"${01}/${001}",
saveWebConDialogListDirPath=
	`${fannelDirPath}/menuList`,
saveWebConDialogJsDirPath=
	`${fannelDirPath}/js`,


// file path
leftMenuListFilePath=
	`${saveWebConDialogListDirPath}/leftMenuList.txt`,
leftLongPressMenuListFilePath=
	`${saveWebConDialogListDirPath}/leftLongPressMenuList.txt`,
centerMenuListFilePath=
	`${saveWebConDialogListDirPath}/centerMenuList.txt`,
centerLongPressMenuListFilePath=
	`${saveWebConDialogListDirPath}/centerLongPressMenuList.txt`,
rightMenuListFilePath=
	`${saveWebConDialogListDirPath}/rightMenuList.txt`,
srcImageAnchorMenuListFilePath=
	`${saveWebConDialogListDirPath}/srcImageAnchorMenuList.txt`,
srcAnchorMenuListFilePath=
	`${saveWebConDialogListDirPath}/srcAnchorMenuList.txt`,
imageMenuListFilePath=
	`${saveWebConDialogListDirPath}/imageMenuList.txt`,

// js path
saveWebConJsPath=
	`${saveWebConDialogJsDirPath}/saveWebCon.js`,

// tsv path
saveWebConArgsTsvPath=
	`${saveWebConDialogJsDirPath}/argsTsv.tsv`,