
// basic
TXT_LABEL="label",
BTN_CMD=cmd,
BTN_LABEL=label,
LIST_PATH=listPath,
LIMIT_NUM=limitNum,

// path
REQ_LIST_DIR_PATH="${01}/${001}",
REQ_LIST_FILE_PATH="${REQ_LIST_DIR_PATH}/reqList",
