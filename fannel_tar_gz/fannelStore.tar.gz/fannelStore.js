

/// LABELING_SECTION_START
// https://github.com/puutaro/fannelStore
/// LABELING_SECTION_END


/// SETTING_SECTION_START
editExecute="ALWAYS"
onAutoExec="ON"
onAdBlock="OFF"
disableSettingValsEdit="ON"
terminalSizeType="LONG"
disableShowToolbarWhenHighlight="OFF"
execPlayBtnLongPress="${webSearcherFannelPath}"
execEditBtnLongPress="PAGE_SEARCH"
srcImageAnchorLongPressMenuFilePath=""
imageAnchorLongPressMenuFilePath=""
defaultMonitorFile="monitor_4"
terminalFontZoom="100"
setReplaceVariables="file://"
setVariableTypes="file://"
hideSettingVariables="file://"
scriptFileName="fannelStore.js"
/// SETTING_SECTION_END


/// CMD_VARIABLE_SECTION_START
SETTING=""
onLaunchBookmarkByDialog="ON"
fannelStoreBookmarkName="fannelStoreBookmark.tsv"
EDIT_FANNEL_STORE_BOOKMARK_NAME=""
/// CMD_VARIABLE_SECTION_END
