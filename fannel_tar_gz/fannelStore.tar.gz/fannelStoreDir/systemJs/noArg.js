

jsimport `${fannelStoreMakeCreatorTsvPathForBookmarkListJsPath}`;
jsimport `${fannelStoreUpdateBookMarkNameJsPath}`;

updateBookMarkName();
jsUrl.loadUrl(`${fannelTopicUrl}`);
