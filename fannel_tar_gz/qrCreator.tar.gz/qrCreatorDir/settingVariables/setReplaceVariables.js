// basic
TXT_LABEL=label,
BTN_CMD=cmd,
BTN_LABEL=label,
LIST_PATH=listPath,
LIMIT_NUM=limitNum,
FCB_DIR_PATH=dirPath,
FCB_PREFIX=prefix,
FCB_SUFFIX=suffix,
FCB_TYPE=type,


// dir path
qrCreatorDirPath=
	"${01}/${001}",
rootDirPath=
	"${00}",
downloadDirPath=
	"${rootDirPath}/temp/download",


// file path
fannelPath=
	"${01}/${02}",
qrCreatorGalleryDirPath=
	"${qrCreatorDirPath}/gallery",
qrCreatorTempDirPath=
	"${qrCreatorDirPath}/temp",

// image path
tempQrPngPath=
	 "${downloadDirPath}/qr.png",