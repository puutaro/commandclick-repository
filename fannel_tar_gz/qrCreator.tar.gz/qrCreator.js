

/// LABELING_SECTION_START
// file://${01}/${001}/image2AsciiArt.md
/// LABELING_SECTION_END


/// SETTING_SECTION_START
editExecute="ALWAYS"
onUpdateLastModify="ON"
onUrlHistoryRegister="OFF"
onAdBlock="OFF"
defaultMonitorFile="term_2"
terminalFontColor=""
setReplaceVariables="file://"
setVariableTypes="file://"
hideSettingVariables="file://"
scriptFileName="qrCreator.js"
/// SETTING_SECTION_END


/// CMD_VARIABLE_SECTION_START
SRC_SETTING="qrCreator.js"
SRC_MODE="text"
/// CMD_VARIABLE_SECTION_END


/// Please write bellow with javascript


