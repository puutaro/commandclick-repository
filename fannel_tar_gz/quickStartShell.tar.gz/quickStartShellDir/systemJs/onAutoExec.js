// js/action

|var=runBoot
	?func=jsUbuntu.boot
|var=runDisplayLong
	?func=jsMonitorSizing.change
		,
