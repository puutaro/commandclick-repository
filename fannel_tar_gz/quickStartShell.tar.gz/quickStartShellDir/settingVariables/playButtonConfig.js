// js/action/setting

click=
	|var=runCmd
		?func=jsUbuntu.execScriptByBackground
		?args=
			shellPath=`${quickStartShellExecuteShellPath}`
			&argsTabSepaStr=``
			&monitorNum=1,

