// js/action/setting

icon=edit,
click=
	|var=runShellEdit
		?func=jsEditor.byEditText
		?args=
			&shellPath=`${quickStartShellExecuteShellPath}`

