

/// LABELING_SECTION_START
// https://github.com/puutaro/japanRouteSearcher
/// LABELING_SECTION_END


/// SETTING_SECTION_START
editExecute="ALWAYS"
onAutoExec="ON"
onAdBlock="ON"
disableSettingValsEdit="ON"
terminalSizeType="LONG"
disableShowToolbarWhenHighlight="OFF"
execPlayBtnLongPress="${webSearcherFannelPath}"
execEditBtnLongPress="PAGE_SEARCH"
srcImageAnchorLongPressMenuFilePath=""
srcAnchorLongPressMenuFilePath=""
defaultMonitorFile="monitor_4"
terminalFontZoom="0"
setReplaceVariables="file://"
setVariableTypes="file://"
hideSettingVariables="file://"
scriptFileName="japanRouteSearcher.js"
/// SETTING_SECTION_END


/// CMD_VARIABLE_SECTION_START
SETTING=""
onLaunchBookmarkByDialog="ON"
lang="en"
japanRouteSearcherBookmarkName="routeBookmark.tsv"
EDIT_FANNEL_STORE_BOOKMARK_NAME=""
/// CMD_VARIABLE_SECTION_END
