

jsimport `${japanRouteSearcherUrlLauncherPath}`;
jsimport `${japanRouteSearcherMakeCreatorTsvPathForBookmarkListJsPath}`;
jsimport `${japanRouteSearcherUpdateBookMarkNameJsPath}`;

updateBookMarkName();

launchJapanRouteSearchUrl();

